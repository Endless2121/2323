<?php
$data = json_decode(file_get_contents('php://input'), true);
$username = $data['username'];
$password = $data['password'];
$days = intval($data['days']);
$start_date = gmdate("Y-m-d\TH:i:s");

$usersFile = 'users.json';
$users = [];

if (file_exists($usersFile)) {
    $users = json_decode(file_get_contents($usersFile), true);
}

if (isset($users[$username])) {
    http_response_code(409);
    echo json_encode(["status" => "error", "message" => "Kullanıcı zaten var."]);
    exit;
}

$users[$username] = [
    "password" => $password,
    "start_date" => $start_date,
    "days" => $days
];

file_put_contents($usersFile, json_encode($users, JSON_PRETTY_PRINT));
echo json_encode(["status" => "success", "message" => "Kullanıcı eklendi."]);
?>
