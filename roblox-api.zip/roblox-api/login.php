<?php
$data = json_decode(file_get_contents('php://input'), true);
$username = $data['username'];
$password = $data['password'];

$usersFile = 'users.json';

if (!file_exists($usersFile)) {
    http_response_code(500);
    echo json_encode(["status" => "error", "message" => "Veri dosyası bulunamadı."]);
    exit;
}

$users = json_decode(file_get_contents($usersFile), true);

if (!isset($users[$username]) || $users[$username]['password'] !== $password) {
    http_response_code(401);
    echo json_encode(["status" => "error", "message" => "Geçersiz kullanıcı adı veya şifre."]);
    exit;
}

// Abonelik süresi kontrolü
$start_date = new DateTime($users[$username]['start_date'], new DateTimeZone("UTC"));
$now = new DateTime("now", new DateTimeZone("UTC"));
$days = $users[$username]['days'];
$expire_date = clone $start_date;
$expire_date->modify("+{$days} days");

if ($now > $expire_date) {
    echo json_encode(["status" => "expired", "message" => "Aboneliğiniz sona erdi."]);
} else {
    $interval = $now->diff($expire_date);
    echo json_encode([
        "status" => "success",
        "remaining" => [
            "days" => $interval->d,
            "hours" => $interval->h,
            "minutes" => $interval->i,
            "seconds" => $interval->s
        ]
    ]);
}
?>
